import { useState, useEffect } from 'react'
import { getUsername, getUserRoles, doLogout } from '../../services/keycloakService'
import { User, Mail, Shield, Calendar, Settings, Edit2, ExternalLink, Lock, Bell, Sparkles } from 'lucide-react'

export default function AccountSettings() {
  const username = getUsername()
  const roles = getUserRoles()
  const [userInfo, setUserInfo] = useState<any>(null)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showPrivacy, setShowPrivacy] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  
  // Form states
  const [editForm, setEditForm] = useState({ name: '', email: '', phone: '' })
  const [notifications, setNotifications] = useState({
    bookingConfirmations: true,
    bookingReminders: true,
    specialOffers: false,
    newsletter: false
  })
  const [privacy, setPrivacy] = useState({
    profileVisible: true,
    historyPrivate: false
  })
  const [showSuccessToast, setShowSuccessToast] = useState(false)
  const [toastMessage, setToastMessage] = useState('')

  // Keycloak account management URL - Updated to use environment variable or default
  const KEYCLOAK_ACCOUNT_URL = import.meta.env.VITE_KEYCLOAK_ACCOUNT_URL || 'http://localhost:8180/realms/salon-booking-realm/account'

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    setUserInfo(user)
    setEditForm({
      name: user?.name || username || '',
      email: user?.email || '',
      phone: user?.phone || ''
    })
    
    // Load saved preferences
    const savedNotifications = localStorage.getItem('notificationSettings')
    if (savedNotifications) {
      setNotifications(JSON.parse(savedNotifications))
    }
    
    const savedPrivacy = localStorage.getItem('privacySettings')
    if (savedPrivacy) {
      setPrivacy(JSON.parse(savedPrivacy))
    }
  }, [username])

  const getRoleLabel = () => {
    if (roles.includes('ADMIN')) return 'Administrator'
    if (roles.includes('SALON_OWNER')) return 'Salon Owner'
    return 'Customer'
  }

  const getRoleColor = () => {
    if (roles.includes('ADMIN')) return 'bg-red-100 text-red-700 border-red-200'
    if (roles.includes('SALON_OWNER')) return 'bg-purple-100 text-purple-700 border-purple-200'
    return 'bg-blue-100 text-blue-700 border-blue-200'
  }

  const handleSaveProfile = () => {
    const updatedUser = { ...userInfo, ...editForm }
    localStorage.setItem('user', JSON.stringify(updatedUser))
    setUserInfo(updatedUser)
    setShowEditModal(false)
    setToastMessage('Profile updated successfully!')
    setShowSuccessToast(true)
    setTimeout(() => setShowSuccessToast(false), 3000)
  }

  const handleSaveNotifications = () => {
    localStorage.setItem('notificationSettings', JSON.stringify(notifications))
    setShowNotifications(false)
    setToastMessage('Notification preferences saved!')
    setShowSuccessToast(true)
    setTimeout(() => setShowSuccessToast(false), 3000)
  }

  const handleSavePrivacy = () => {
    localStorage.setItem('privacySettings', JSON.stringify(privacy))
    setShowPrivacy(false)
    setToastMessage('Privacy settings saved!')
    setShowSuccessToast(true)
    setTimeout(() => setShowSuccessToast(false), 3000)
  }

  const handleDeleteAccount = () => {
    // Clear all local data
    localStorage.clear()
    sessionStorage.clear()
    
    // Close the modal first
    setShowDeleteConfirm(false)
    
    // Small delay to let modal close, then logout
    setTimeout(() => {
      doLogout()
    }, 300)
  }

  const openKeycloakAccount = () => {
    window.open(KEYCLOAK_ACCOUNT_URL, '_blank', 'noopener,noreferrer')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-slate-900 mb-3">Account Settings</h1>
          <p className="text-lg text-slate-600">Manage your profile and account preferences</p>
        </div>

        {/* Main Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
              {/* Profile Header with Gradient */}
              <div className="h-24 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
              
              <div className="px-6 pb-6 -mt-12 relative">
                <div className="flex justify-center mb-4">
                  <div className="w-24 h-24 rounded-2xl bg-white shadow-lg flex items-center justify-center border-4 border-white">
                    <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white text-3xl font-bold">
                      {username?.charAt(0).toUpperCase() || 'U'}
                    </div>
                  </div>
                </div>

                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-slate-900 mb-2">
                    {userInfo?.name || username}
                  </h2>
                  <p className="text-sm text-slate-600 mb-3">{userInfo?.email}</p>
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg border ${getRoleColor()} font-semibold text-sm`}>
                    <Shield className="w-4 h-4" />
                    {getRoleLabel()}
                  </div>
                </div>

                <div className="space-y-3 pt-6 border-t border-slate-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 font-medium">Member since</span>
                    <span className="text-sm font-semibold text-slate-900">
                      {userInfo?.created_timestamp 
                        ? new Date(userInfo.created_timestamp).toLocaleDateString('en-US', { 
                            month: 'short', 
                            year: 'numeric' 
                          })
                        : 'Recently'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 font-medium">Status</span>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                      Active
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-600 font-medium">Total Bookings</span>
                    <span className="text-sm font-semibold text-slate-900">
                      {userInfo?.totalBookings || 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Information */}
            <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
              <div className="px-6 py-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
                <h3 className="text-xl font-bold text-slate-900">Personal Information</h3>
                <p className="text-sm text-slate-600 mt-1">Your account details and profile information</p>
              </div>
              <div className="p-6">
                <div className="grid gap-5">
                  <div className="group">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Username
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <User className="w-5 h-5 text-slate-400" />
                      </div>
                      <input 
                        type="text" 
                        value={username} 
                        readOnly
                        className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  <div className="group">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">
                      Email Address
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <Mail className="w-5 h-5 text-slate-400" />
                      </div>
                      <input 
                        type="email" 
                        value={userInfo?.email || 'Not provided'} 
                        readOnly
                        className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div className="group">
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Account Type
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                          <Shield className="w-5 h-5 text-slate-400" />
                        </div>
                        <input 
                          type="text" 
                          value={getRoleLabel()} 
                          readOnly
                          className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="group">
                      <label className="block text-sm font-semibold text-slate-700 mb-2">
                        Joined Date
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                          <Calendar className="w-5 h-5 text-slate-400" />
                        </div>
                        <input 
                          type="text" 
                          value={userInfo?.created_timestamp 
                            ? new Date(userInfo.created_timestamp).toLocaleDateString()
                            : 'Recently joined'} 
                          readOnly
                          className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-medium focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid sm:grid-cols-2 gap-6">
              <button
                onClick={openKeycloakAccount}
                className="group bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl p-6 shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition-all duration-300 text-left"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                    <Settings className="w-6 h-6 text-white" />
                  </div>
                  <ExternalLink className="w-5 h-5 text-white/70 group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Manage in Keycloak</h3>
                <p className="text-blue-100 text-sm">Update password, security, and authentication settings</p>
              </button>

              <button 
                onClick={() => setShowEditModal(true)}
                className="group bg-white rounded-2xl p-6 shadow-lg border border-slate-200 hover:shadow-2xl hover:border-blue-300 transform hover:-translate-y-1 transition-all duration-300 text-left">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl flex items-center justify-center">
                    <Edit2 className="w-6 h-6 text-purple-600" />
                  </div>
                  <Sparkles className="w-5 h-5 text-slate-400 group-hover:text-purple-600 transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Edit Profile</h3>
                <p className="text-slate-600 text-sm">Customize your profile and preferences</p>
              </button>

              <button 
                onClick={() => setShowNotifications(true)}
                className="group bg-white rounded-2xl p-6 shadow-lg border border-slate-200 hover:shadow-2xl hover:border-emerald-300 transform hover:-translate-y-1 transition-all duration-300 text-left">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-xl flex items-center justify-center">
                    <Bell className="w-6 h-6 text-emerald-600" />
                  </div>
                  <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">
                      {Object.values(notifications).filter(Boolean).length}
                    </span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Notifications</h3>
                <p className="text-slate-600 text-sm">Manage your notification preferences</p>
              </button>

              <button 
                onClick={() => setShowPrivacy(true)}
                className="group bg-white rounded-2xl p-6 shadow-lg border border-slate-200 hover:shadow-2xl hover:border-amber-300 transform hover:-translate-y-1 transition-all duration-300 text-left">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl flex items-center justify-center">
                    <Lock className="w-6 h-6 text-amber-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Privacy & Security</h3>
                <p className="text-slate-600 text-sm">Control your privacy and security settings</p>
              </button>
            </div>

            {/* Info Banner */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Secure Account Management</h4>
                  <p className="text-slate-700 text-sm leading-relaxed mb-3">
                    Your account is protected by Keycloak's enterprise-grade security. For advanced security 
                    features like two-factor authentication, password updates, and session management, 
                    visit the Keycloak account portal.
                  </p>
                  <button
                    onClick={openKeycloakAccount}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors"
                  >
                    Open Keycloak Account
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      {showEditModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900">Edit Profile</h3>
              <p className="text-sm text-slate-600 mt-1">Update your personal information</p>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Full Name</label>
                <input 
                  type="text" 
                  value={editForm.name}
                  onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Email</label>
                <input 
                  type="email" 
                  value={editForm.email}
                  onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Phone Number</label>
                <input 
                  type="tel" 
                  value={editForm.phone}
                  onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                  placeholder="+1 (555) 000-0000"
                  className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button 
                onClick={() => setShowEditModal(false)}
                className="flex-1 px-4 py-3 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleSaveProfile}
                className="flex-1 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Notifications Modal */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900">Notification Settings</h3>
              <p className="text-sm text-slate-600 mt-1">Manage how you receive notifications</p>
            </div>
            <div className="p-6 space-y-4">
              {[
                { key: 'bookingConfirmations', title: 'Booking Confirmations', desc: 'Get notified when your booking is confirmed' },
                { key: 'bookingReminders', title: 'Booking Reminders', desc: 'Receive reminders before your appointments' },
                { key: 'specialOffers', title: 'Special Offers', desc: 'Get updates about promotions and deals' },
                { key: 'newsletter', title: 'Newsletter', desc: 'Receive our weekly newsletter' }
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                  <div>
                    <p className="font-semibold text-slate-900">{item.title}</p>
                    <p className="text-sm text-slate-600">{item.desc}</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={notifications[item.key as keyof typeof notifications]}
                      onChange={(e) => setNotifications({...notifications, [item.key]: e.target.checked})}
                    />
                    <div className="w-11 h-6 bg-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                  </label>
                </div>
              ))}
            </div>
            <div className="p-6 border-t border-slate-200">
              <button 
                onClick={handleSaveNotifications}
                className="w-full px-4 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all"
              >
                Save Preferences
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Privacy & Security Modal */}
      {showPrivacy && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900">Privacy & Security</h3>
              <p className="text-sm text-slate-600 mt-1">Manage your privacy and security settings</p>
            </div>
            <div className="p-6 space-y-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-blue-900 mb-1">Two-Factor Authentication</p>
                    <p className="text-sm text-blue-700 mb-3">Add an extra layer of security to your account</p>
                    <button
                      onClick={openKeycloakAccount}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-colors"
                    >
                      Enable in Keycloak
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-semibold text-slate-900">Profile Visibility</p>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={privacy.profileVisible}
                      onChange={(e) => setPrivacy({...privacy, profileVisible: e.target.checked})}
                    />
                    <div className="w-11 h-6 bg-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>
                <p className="text-sm text-slate-600">Allow others to see your profile</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-semibold text-slate-900">Booking History</p>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={privacy.historyPrivate}
                      onChange={(e) => setPrivacy({...privacy, historyPrivate: e.target.checked})}
                    />
                    <div className="w-11 h-6 bg-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
                  </label>
                </div>
                <p className="text-sm text-slate-600">Make your booking history private</p>
              </div>

              <div className="p-4 border-2 border-red-200 bg-red-50 rounded-xl">
                <p className="font-semibold text-red-900 mb-2">Delete Account</p>
                <p className="text-sm text-red-700 mb-3">
                  This will clear your local data and log you out. To permanently delete your Keycloak account, 
                  please visit the Keycloak account management portal.
                </p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setShowDeleteConfirm(true)}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-semibold hover:bg-red-700 transition-colors"
                  >
                    Clear Data & Logout
                  </button>
                  <button
                    onClick={openKeycloakAccount}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors"
                  >
                    Manage in Keycloak
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-slate-200">
              <button 
                onClick={handleSavePrivacy}
                className="w-full px-4 py-3 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800 transition-all"
              >
                Save Settings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Account Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full">
            <div className="p-6 border-b border-slate-200">
              <h3 className="text-2xl font-bold text-red-600">Clear Data & Logout?</h3>
            </div>
            <div className="p-6">
              <p className="text-slate-700 mb-4">
                This action will:
              </p>
              <ul className="list-disc list-inside text-slate-600 space-y-2 mb-6">
                <li>Clear all local application data</li>
                <li>Log you out from the application</li>
                <li>Remove saved preferences</li>
                <li>End your current session</li>
              </ul>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> To permanently delete your Keycloak account and all associated data, 
                  you must do so through the Keycloak account management portal.
                </p>
              </div>
              <p className="text-slate-700 font-semibold">
                Do you want to continue?
              </p>
            </div>
            <div className="p-6 border-t border-slate-200 flex gap-3">
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 px-4 py-3 border border-slate-300 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleDeleteAccount}
                className="flex-1 px-4 py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition-all"
              >
                Yes, Logout
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Success Toast Notification */}
      {showSuccessToast && (
        <div className="fixed bottom-8 right-8 z-[70] animate-slideUp">
          <div className="bg-emerald-600 text-white px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 min-w-[300px]">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </div>
            <p className="font-semibold">{toastMessage}</p>
          </div>
        </div>
      )}
      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-slideUp {
          animation: slideUp 0.3s ease-out;
        }
      `}</style>
    </div>
  )
}